import datetime
import random
print(random.random())
print(random.uniform(1,10))
random.seed(a= datetime.datetime.isoformat, version =2)
print(random.uniform(1,100))